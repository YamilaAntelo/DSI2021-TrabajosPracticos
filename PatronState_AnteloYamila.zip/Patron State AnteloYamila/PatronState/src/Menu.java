import java.util.Scanner;

public class Menu {

    private Tamagotchi tamagotchi;

    public Menu(Tamagotchi tamagotchi)
    {
        this.tamagotchi = tamagotchi;
    }

    public void display()
    {
        Scanner scanner = new Scanner(System.in);

        char opcion;

        String mensajeOpciones = " Realizar accion " +
                " a) Alimentar , d) Dormir, j) Jugar, p) Preguntar, s) Salir";

        while (true)
        {
            System.out.print(mensajeOpciones);
            opcion = scanner.next().charAt(0);

            switch (opcion)
            {
                case 'a':
                    tamagotchi.alimentar();
                    break;
                case 'd':
                    tamagotchi.dormir();
                    break;
                case 'j':
                    tamagotchi.jugar();
                    break;
                case 'p':
                    tamagotchi.comoEstas();
                    break;
                case 's':
                    System.out.print(" Has Salido ");
                    break;
                default:
                    System.out.print(" Opcion no valida ");
            }
        }
    }
}
