public class Aburrido implements State{

    private Tamagotchi tamagotchi;

    @Override
    public void jugar() {
        System.out.print(" Ya! Juguemos! ");
        tamagotchi.setState(new Cansado());
    }

    @Override
    public void alimentar() {
        System.out.print(" No quiero comer ");
    }

    @Override
    public void dormir() {
        System.out.print(" No quiero dormir ");
    }

    @Override
    public void comoEstas() {
        System.out.print(" Estoy aburrido! , quiero jugar ");
    }

    @Override
    public void setTamagotchi(Tamagotchi tamagotchi) {
        this.tamagotchi = tamagotchi;
    }
}
